####################################################
## GeekShed Management Script (XChat Port)        ##
## Concept by Zetacon                             ##
## Input/Modifications by:                        ##
## Phil, GrimReaper, Ryan, Freekie                ##
## Porting to XChat by:                           ##
## Auv5                                           ##
## All Rights Reserved                            ##
####################################################

__module_name__ = "GeekShed XChat Management Script"
__module_version__ = "0.01" 
__module_description__ = "Manage your channel on GeekShed or help out in #help with ease!"

import xchat

print "\0034",__module_name__, __module_version__,"loading...\003"

## Allows you to set someone else to have founder rights (9999 access 
## rights) on the channel, 
## also attempts to turn off 
## the Xop system.
def SetFounder(word, word_eol, userdata):
	global chan
	global accnickf
	try:
            word[1]
	except IndexError:
            xchat.prnt("please specify a name to give founder rights to. syntax is '/founder <NickName>'")
	else:
            accnickf = word[1]
	    chan = xchat.get_info("channel")
	    xchat.command("cs SET " + chan + " XOP off")
	    xchat.prnt("The nick " + accnickf + " has been set as a founder of" + chan + ". They must now cycle it and rejoin it. XOP has been turned OFF! This means that you must now use the access system. For help doing this, visit http://www.geekshed.net/2009/12/access-system-tutorial/")
            xchat.command("cs access " + chan + " ADD " + accnickf + " 9999")
	return xchat.EAT_ALL
def Xop(word, word_eol, userdata):
        chan = xchat.get_info("channel")
	try:
            word[1]
            word[2]
	except IndexError:
            xchat.prnt("Please specify a list and a person you want to put on that list in the format '/xop <HOP|AOP|SOP> <NickName>'")
        else:
            xchat.command("cs " + word[1] + " " + chan + " add " + word[2])
            xchat.command("cs sync " + chan)
        return xchat.EAT_ALL





xchat.hook_command('founder', SetFounder)
xchat.hook_command('permxop', Xop)

####################################################
## GeekShed Management Script (XChat Port)        ##
## Concept by Zetacon                             ##
## Input/Modifications by:                        ##
## Phil, GrimReaper, Ryan, Freekie                ##
## Porting to XChat by:                           ##
## Auv5                                           ##
## All Rights Reserved                            ##
####################################################

__module_name__ = "GeekShed XChat Management Script"
__module_version__ = "1.2"
__module_description__ = "Manage your channel on GeekShed or help out in #help with ease!"

import xchat

print "\0034",__module_name__, __module_version__,"loading...\003"


## Allows you to set someone else to have founder rights (9999 access 
## rights) on the channel, 
## also attempts to turn off 
## the Xop system.

def TimeBan(word, word_eol, userdata):
       global chan
       try:
         word[1]
         word[3]
       except IndexError:
         xchat.prnt("Please use the correct syntax")
       else:
         xchat.command("kbtemp_set bantime " + word[3])
         xchat.command("kbtemp " + word[1])
       return xchat.EAT_ALL

def AccAdd(word, word_eol, userdata):
        chan = xchat.get_info("channel")
	try:
            word[1]
            word[2]
	except IndexError:
            xchat.prnt("Please specify a list and a person you want to put on that list in the format '/permacc <HOP|AOP|SOP> <NickName>'")
        else:
            xchat.command("cs " + "access " + chan + " add " + word[1] + " " + word[2])
            xchat.command("cs sync " + chan)
        return xchat.EAT_ALL





xchat.hook_command('permxop', TimeBan)
xchat.hook_command('permacc', AccAdd)
